package br.com.ucb.main;

import br.com.ucb.clinica.Cachorro;
import br.com.ucb.clinica.Gato;
import br.com.ucb.clinica.Passaro;

public class Main {

	public static void main(String[] args) {
		Cachorro objCachorro = new Cachorro("Magrelo", 6, "caramelo");
		objCachorro.farejar();
		objCachorro.fazerSom();
		Gato objGato = new Gato("taylor", 2, "egipicio");
		objGato.arranhar();
		objGato.fazerSom();
		
		Passaro objPassaro = new Passaro("Jose", 4, "arara", "longo");
		objPassaro.voar();
		objPassaro.fazerSom();
	}

	}
	