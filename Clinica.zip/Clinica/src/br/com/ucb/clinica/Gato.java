package br.com.ucb.clinica;

public class Gato extends Animal{
	private String cor;
	
	//construtor
	public Gato(String nome, int idade, String tipoAnimal) {
		super(nome, idade, tipoAnimal);
		
	}
@Override
	public void fazerSom() {
		// TODO Auto-generated method stub
		super.fazerSom();
		System.out.println("meow meow");
	}
// get e set
public String getCor() {
	return cor;
}

public void setCor(String cor) {
	this.cor = cor;
}

public void arranhar() {
	System.out.println(" gato está arranhando");
	
}

  
}
