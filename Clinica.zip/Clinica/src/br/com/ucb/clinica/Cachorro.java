package br.com.ucb.clinica;

public class Cachorro extends Animal{

	private String fucinho;
	
	public Cachorro(String nome, int idade, String tipoAnimal) {
		super(nome, idade, tipoAnimal);
	
	}

 public void farejar() {
	 System.out.println("cachorro está farejando");
 }

@Override
public void fazerSom() {
	// TODO Auto-generated method stub
	super.fazerSom();
	System.out.println("Auau");
}
//get e set
public String getFucinho() {
	return fucinho;
}

public void setFucinho(String fucinho) {
	this.fucinho = fucinho;
}
 
}
