package br.com.ucb.clinica;

public class Passaro extends Animal{
 private String Bico;

public Passaro(String nome, int idade, String tipoAnimal, String Bico) {
	super(nome, idade, tipoAnimal);
	this.Bico = Bico;
}


 @Override
public void fazerSom() {
	// TODO Auto-generated method stub
	super.fazerSom();
	System.out.println("OLA OLA OLA");
}


public void voar () {
	 System.out.println("Passaro está voando");
 }
 //get e set
public String getBico() {
	return Bico;
}
public void setBico(String bico) {
	Bico = bico;
}
 
}
